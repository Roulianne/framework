<?php
namespace Core\Dao\Php;

use Core\Dao\Php\PhpDao as PhpDao,
    Core\Dao\Php\Accessible as Accessible,
    \Exception;

/**
* This is the description for my class.
*
* @class CsvDao
* @constructor
*/
class CsvDao extends PhpDao implements Accessible
{

    public  $TYPE         = 'CSV';

    /**
     * [_loadFileData description]
     * @return [type] [description]
     */
    protected function _loadFileData(){
        $sFolder = rtrim( $this->_sFolder, '/');
        $this->_aDataFile = $this->_loadData( $sFolder.'/'.$this->_getCondition( 'type').'.csv', "|");
    }

    /**
     * @method _loadData description
     * @param  String $sFile      [description]
     * @param  String $sDelimiter [description]
     * @return Array [description]
     */
    private function _loadData($sFile, $sDelimiter)
    {
        $aAttribute  = array();
        $aDataResult = array();

        if (($handle = fopen( $sFile, "r")) !== FALSE) {

            while ( ( $aData = fgetcsv( $handle, 0, $sDelimiter)) !== FALSE) {
                if ( empty( $aAttribute)) {
                    $aAttribute = array_map( 'strtolower', $aData);
                } else {
                    $aDataResult[] = array_combine( $aAttribute, $aData);
                }
            }

            fclose($handle);
        }

        return $aDataResult;
    }

    /**
     * @method read description
     * @param  Array  $aData [description]
     * @return Array [description]
     */
    public function read( $aSelect = array())
    {
        return parent::read( $aSelect);
    }

    /**
     * @method create description
     * @param  array  $aData
     * @return null
     */
    public function create(array $aData)
    {
        return null;
    }

    /**
     * @method update description
     * @param  array  $aData
     * @return null
     */
    public function update(array $aData)
    {
       return null;
    }

    /**
     * @method delete description
     * @return null
     */
    public function delete()
    {
        return null;
    }

    /**
     * [getStructure description]
     * @param  [type] $oElment [description]
     * @return [type]          [description]
     */
    public function options( $oElement){
         return $oElement->getStructure();
    }

    /**
     * [setCondition description]
     * @param [type] $aWhere [description]
     */
    public function setCondition(array $aWhere = array())
    {
        parent::setCondition( $aWhere);
        return $this;
    }

    /**
     * [setCustomCondition description]
     * @param string $sString [description]
     */
    public function setCustomCondition( array $mParam = array())
    {
        parent::setCondition( $mParam);
        return $this;
    }
}
