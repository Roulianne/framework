<?php
namespace Core\Dao\Php;

use Core\Dao\Php\PhpDao as PhpDao,
    Core\Dao\Php\Accessible as Accessible,
    \Exception;

class JsonDao extends PhpDao implements Accessible
{

    public  $TYPE         = 'JSON';

    /**
     * [_loadFileData description]
     * @return [type] [description]
     */
    protected function _loadFileData(){
        $sFolder = rtrim( $this->_sFolder, '/');
        $this->_aDataFile = json_decode( file_get_contents( $sFolder.'/'.$this->_getCondition( 'type').'.json'), true);
    }

    /**
    * [read description]
    * @param  array  $aData [description]
    * @return [type]        [description]
    */
    public function read(  $aSelect = array())
    {
        return parent::read(  $aSelect);
    }

    /**
     * [create description]
     * @param  [type] $sTable
     * @param  array  $aData
     * @return [type]
     */
    public function create(array $aData)
    {
        //
    }

    /**
     * [update description]
     * @param  [type] $sTable
     * @param  array  $aData
     * @param  array  $aWhere
     * @return [type]
     */
    public function update(array $aData)
    {
        //
    }

    /**
     * [delete description]
     * @param  [type] $sTable
     * @param  array  $aWhere
     * @return [type]
     */
    public function delete()
    {
        //
    }

    /**
    * [getStructure description]
    * @param  object $oElment [description]
    * @return [type]          [description]
    */
    public function options( $oElement)
    {
        return $oElement->getStructure();
    }


    /**
     * [setCustomCondition description]
     * @param string $sString [description]
     */
    public function setCustomCondition(array $aParams = array())
    {
        return $this;
    }
}
