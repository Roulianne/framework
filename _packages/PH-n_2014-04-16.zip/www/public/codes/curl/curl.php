<?php

use Main\View\View as View,
	Main\App\App as App,
	Main\Conf\Conf as Conf,
	Main\Uploader\Uploader as Uploader,
	Core\Rest\Client as Client,
	Main\Route\Route as Route;

$sResponse = 'vide';

$aData = Route::post()->getData();

function clean( $sValue){
	return ltrim( $sValue, '@');
}

if( count( $aData)>0){


	$oRestClient = Client::getInstance( 'stream');
	$oRestClient->setUrl( $aData['url']);

	switch( $aData['method']){

		case 'post':
			$aData = array_map( 'clean', $aData);
			$aResponse = $oRestClient->post( $aData);
			break;

		case 'put':
			$aData = array_map( 'clean', $aData);
			$aResponse = $oRestClient->put( $aData);
			break;

		case 'delete':
			$aResponse = $oRestClient->delete();
			break;

		default:
			$aResponse = $oRestClient->get();
			break;
	}
	$sResponse = $aResponse['content'];
}


View::scope('*.textarea')->response  = htmlentities( $sResponse) ;
View::scope('*.textarea')->apiUrl    = ( isset( $aData['url']))? $aData['url'] : Conf::get('app.http_root').'api.json' ;

View::make( 'general.curl-test');