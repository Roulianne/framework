<?php

namespace Core\Rest\Client;

use Core\Rest\Client\Streaming       as Streaming;

class Curl extends Streaming
{
   private $_fCurl     = null;

   /**
    * [__construct description]
    */
   public function __construct(){
      $this->_fCurl = curl_init();
   }

   /**
    * [_createContext description]
    * @param  [type] $pMethod  [description]
    * @param  [type] $aData [description]
    * @return [type]           [description]
    */
   protected function _createContext($pMethod, $aData = null){
     $aOption = array();

     switch( $pMethod){

        case'POST':
          $aOption = array(
                      CURLOPT_POST=>1,
                      CURLOPT_POSTFIELDS=>$aData,
                    );
          break;

        case'PUT':
          $aOption = array(
                      CURLOPT_CUSTOMREQUEST=>"PUT",
                      CURLOPT_POSTFIELDS=>http_build_query($aData),
                    );
          break;

        case'DELETE':
          $aOption = array(
                      CURLOPT_CUSTOMREQUEST=>"DELETE",
                    );
          break;

        case'GET':
        default:
          break;

     }

     return $aOption;
   }

   /**
    * [_launch description]
    * @param  [type] $pUrl    [description]
    * @param  [type] $context [description]
    * @return [type]          [description]
    */
   protected function _launch ($pUrl, $context){

        curl_setopt( $this->_fCurl, CURLOPT_URL, $pUrl);

        curl_setopt( $this->_fCurl, CURLOPT_HEADER, false);
        curl_setopt( $this->_fCurl, CURLOPT_VERBOSE , true);
        curl_setopt( $this->_fCurl, CURLOPT_BINARYTRANSFER, true);
        curl_setopt( $this->_fCurl, CURLOPT_RETURNTRANSFER, true);

        curl_setopt_array( $this->_fCurl, $context);

        $sResponse = curl_exec( $this->_fCurl);

        $aResponse = array(
              'content' => $sResponse,
              'header'  => '',
          );

        curl_close( $this->_fCurl);
        return $aResponse;
   }

}
