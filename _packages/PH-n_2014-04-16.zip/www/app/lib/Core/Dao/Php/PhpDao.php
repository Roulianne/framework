<?php
namespace Core\Dao\Php;

use Core\Dao\Php\Accessible as Accessible,
    \Exception;

class PhpDao implements Accessible
{
    protected $_aDataFile = array();

    protected $_aWhere    = array();

    /**
     * [__construct description]
     * @param [type] $sFile
     */
   public function __construct($aParams)
   {
        if ( is_array( $aParams) and array_key_exists('file', $aParams)) {
            $this->_aDataFile = $this->_loadPhpArray( $aParams['file']);
        } else {
            throw new Exception("Failed to open the file");
        }
    }

    /**
     * [_getCondition description]
     * @param  [type] $sKey [description]
     * @return [type] [description]
     */
    private function _getCondition($sKey = NULL)
    {
       $mValue = NULL;

       if ($sKey == NULL) {
            $mValue = $this->_aWhere;
       } else {
            $mValue = (array_key_exists( $sKey, $this->_aWhere))? $this->_aWhere[$sKey] : NULL;
       }

       return $mValue;
    }

    /**
     * [_searchOnArray description]
     * @param  [type] $array  [description]
     * @param  [type] $aWhere [description]
     * @return [type] [description]
     */
    private function _searchOnArray($aData, $aWhere)
    {
        $aResult = array();

        $aWhere  = array_change_key_case( $aWhere, CASE_LOWER);

        foreach ($aData as $aInfo) {
            $bValid = true;
            foreach ((array) $aWhere as $sKey => $sValue) {

                if ( !array_key_exists( $sKey, $aInfo)|| $aInfo[$sKey] != $sValue) {
                    $bValid = false;
                    continue 2;
                }
            }

            if($bValid)
                $aResult[] = $aInfo;
        }

        return $aResult;
    }

    /**
     * [getFormatValues description]
     * @param  [type] $aData
     * @return [type]
     */
    private function _loadPhpArray($sFile)
    {
        return include($sFile);
    }

    /**
     * [read description]
     * @param  [type] $sTable
     * @param  [type] $aWhere
     * @return [type]
     */
    public function read( $aSelect = array())
    {
        $sKey    = $this->_getCondition( 'type');
        $aWhere  = $this->_getCondition( 'where');
        $aResult = array();

        $aSearch = ($sKey != NULL && array_key_exists( $sKey, $this->_aDataFile))?
                        $this->_aDataFile[$sKey] :
                        $this->_aDataFile;

        if ( $aWhere == NULL || empty( $aWhere)) {
            $aResult = $aSearch;
        } else {
            $aResult = $this->_searchOnArray( $aSearch, $aWhere);
        }

        return $aResult;
    }

    /**
     * [create description]
     * @param  [type] $sTable
     * @param  array  $aData
     * @return [type]
     */
    public function create(array $aData)
    {
        //
    }

    /**
     * [update description]
     * @param  [type] $sTable
     * @param  array  $aData
     * @param  array  $aWhere
     * @return [type]
     */
    public function update(array $aData)
    {
        //
    }

    /**
     * [delete description]
     * @param  [type] $sTable
     * @param  array  $aWhere
     * @return [type]
     */
    public function delete()
    {
        //
    }

    /**
     * [setCondition description]
     * @param [type] $aWhere [description]
     */
    public function setCondition(array $aWhere = NULL)
    {
        if (is_array( $aWhere)) {
            $this->_aWhere = $aWhere;
        }

        return $this;
    }

    /**
     * [setCustomCondition description]
     * @param string $sString [description]
     */
    public function setCustomCondition( $mString = null)
    {
        return $this;
    }

    /**
     * [getData description]
     * @return [type] [description]
     */
    public function getData()
    {
        return $this->_aDataFile;
    }

    /**
     * [mergeData description]
     * @param  [type] $aOld [description]
     * @return [type] [description]
     */
    public function mergeData($aOld)
    {
        $this->_aDataFile = array_merge( $aOld, $this->_aDataFile);

        return $this;
    }
}
