<?php
namespace Core\Dao\Php;

use Core\Dao\Php\Accessible as Accessible,
    Core\Rest\Client as Client;

class ApiDao implements Accessible
{

    private $_aWhere      = array();

    private $_oClient     = null;

    /**
     * [__construct description]
     * @param [type] $sDsn
     * @param [type] $sUsername
     * @param [type] $sPassword
     * @param array  $aOptions
     */
    public function __construct( $aParams){

        if ( empty( $aParams)) {
            throw new Exception("Empty params");
        } else {

            $this->_sRootUrl       = rtrim( $aParams['root'], '/').'/';

            $this->_aApiLog        = $aParams['log'];
            $this->_sApiParameters = $aParams['parameters'];

            $this->_treatPattern( $aParams['pattern']);

            $this->_oClient        = Client::getInstance();
        }
    }

    /**
     * [_treatPattern description]
     * @param  [type] $aPattern [description]
     * @return [type]           [description]
     */
    private function _treatPattern( $aPattern){
        $this->_aPatternUrl = array();
        return $this;
    }

    /**
     * [_buildUrl description]
     * @return [type] [description]
     */
    private function _buildUrl( $aData = array()){

    }

    /**
     * [read description]
     * @param  [type] $sTable
     * @param  [type] $aWhere
     * @return [type]
     */
    public function read( $aSelect = array())
    {
        $aValues = array();

        return $aValues;
    }

    /**
     * [create description]
     * @param  [type] $sTable
     * @param  array  $aData
     * @return [type]
     */
    public function create(array $aData)
    {
        $this->_oClient->setUrl( );
        $aResponse = $this->_oClient->post( $aData);
    }

    /**
     * [update description]
     * @param  [type] $sTable
     * @param  array  $aData
     * @param  array  $aWhere
     * @return [type]
     */
    public function update(array $aData){

    }

    /**
     * [delete description]
     * @param  [type] $sTable
     * @param  array  $aWhere
     * @return [type]
     */
    public function delete(){

    }

    /**
     * [setCustomCondition description]
     * @param string $sString [description]
     */
    public function setCustomCondition( $mString = null)
    {
        return $this;
    }

    /**
     * [setCondition description]
     * @param [type] $aWhere [description]
     */
    public function setCondition(array $aWhere = NULL)
    {
        if (is_array( $aWhere)) {
            $this->_aWhere = $aWhere;
        }

        return $this;
    }
}
