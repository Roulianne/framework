<?php
/*

use Main\App\App               as App,
    Main\Conf\Conf             as Conf,
    Main\View\View             as View,
    Main\Route\Route           as Route,
    Main\Event\Event           as Event,
    Main\Translator\Translator as Translator,
    Main\Controller\Controller as Controller;

*/

$oBase = new Base();
$oBase->buildSchema( 'sherfi_fabrique');


echo  $oBase->bookmarks->getPrefix();

