<?php

namespace Main\Builder;

use Main\Builder\Champ as Champ;

class Table{

	/**
	 * [$_aSchema description]
	 * @var array
	 */
	private $_aSchema  = array();

	private $_sPrefix  = null;

	private $_sReferer = '';

	private $_sTable   = '';

	/**
	 * [$_aChamp description]
	 * @var array
	 */
	private $_aChamp  = array();

	/**
	 * [__construct description]
	 * @param array $aChamp [description]
	 */
	function __construct( $aChamp = array()){

		$this->_aSchema = $aChamp;
		$this->_setChamp();
	}

	/**
	 * [_setChamp description]
	 */
	private function _setChamp(){
		if( !empty( $this->_aSchema)){
			foreach ($this->_aSchema as $sChamp => $aInfo) {
				$sChamp = strtolower( $sChamp);
				$this->_aChamp[ $sChamp] = new Champ( $aInfo);
			}
		}
	}

	/**
	 * [getPrefix description]
	 * @return [type] [description]
	 */
	public function getPrefix(){
		if( is_null( $this->_sPrefix)){
			$aChamp       = $this->getListChamp();
			$iCount       = count( $aChamp);
			$sStartPrefix = $aChamp[0];

			for( $i = 0;  $i < $iCount ; $i++){
				$sPrefix = '';
				$m = 0;
				$aChampCurrent = $aChamp[$i];

				echo $aChamp[$i] .'<br/>';
				while( $sStartPrefix[$m] == $aChampCurrent[$m]){
					$sPrefix .= $sStartPrefix[$m];
					$m++;
				}
				$sStartPrefix = $sPrefix;
			}
			$this->_sPrefix = $sPrefix;
		}
		return $this->_sPrefix;
	}

	/**
	 * [getReferer description]
	 * @return [type] [description]
	 */
	public function getReferer(){
		if( $this->_sReferer == ''){
			foreach( $this->getChamp() as $oChamp){
				if( $oChamp->isPrimary()){
					return $oChamp;
				}
			}
		}
		return $this->_sReferer;
	}

	/**
	 * [getListChamp description]
	 * @return [type] [description]
	 */
	public function getListChamp(){
		return array_keys( $this->_aChamp);
	}

	/**
	 * [getListChamp description]
	 * @return [type] [description]
	 */
	public function getChamp(){
		return $this->_aChamp;
	}

	/**
	 * [__get description]
	 * @param  [type] $sChamp [description]
	 * @return [type]         [description]
	 */
	public function __get( $sChamp){
		$sChamp = strtolower( $sChamp);
		if( array_key_exists( $sChamp, $this->_aChamp)){
			return $this->_aChamp[ $sChamp];
		}
	}

}
