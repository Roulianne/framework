<?php

namespace Core\Rest\Client;

class Client
{
   private $_url;

   /**
    * [__construct description]
    */
   public function __construct(){}

   /**
    * [_createContext description]
    * @param  [type] $pMethod  [description]
    * @param  [type] $aData [description]
    * @return [type]           [description]
    */
   protected function _createContext($pMethod, $aData = null){
      $opts = array(
              'http'=>array(
                            'method'=>$pMethod,
                            'header'=>'Content-type: application/x-www-form-urlencoded',
                          )
              );

      if ($aData !== null){

         if (is_array($aData)){
            $aData = http_build_query($aData);
         }

         $opts['http']['content'] = $aData;
      }

      return stream_context_create( $opts);
   }

   /**
    * [_makeUrl description]
    * @param  [type] $pParams [description]
    * @return [type]          [description]
    */
   protected function _makeUrl($pParams){
      return $this->_url
             .(strpos( $this->_url, '?') ? '' : '?') . http_build_query( $pParams);
   }

   /**
    * [_launch description]
    * @param  [type] $pUrl    [description]
    * @param  [type] $context [description]
    * @return [type]          [description]
    */
   protected function _launch ($pUrl, $context){
        if ( ( $stream = fopen( $pUrl, 'r', false, $context)) !== false){
            $content = stream_get_contents( $stream);
            $header  = stream_get_meta_data( $stream);
            fclose( $stream);
            return array('content'=>$content, 'header'=>$header);
        }else{
            return false;
        }
   }

   /**
    * [setUrl description]
    * @param [type] $pUrl [description]
    */
   public function setUrl ($pUrl){
      $this->_url = $pUrl;
      return $this;
   }

   /**
    * [read description]
    * @param  array  $pParams [description]
    * @return [type]          [description]
    */
   public function get ($aGetData = array()){
      return $this->_launch($this->_makeUrl( $aGetData),
                            $this->_createContext('GET'));
   }

   /**
    * [add description]
    * @param array $pPostParams [description]
    * @param array $aGetData  [description]
    */
   public function post ($pPostParams=array(), $aGetData = array()){
      return $this->_launch($this->_makeUrl( $aGetData),
                            $this->_createContext('POST', $pPostParams));
   }

   /**
    * [update description]
    * @param  [type] $aData   [description]
    * @param  array  $aGetData [description]
    * @return [type]             [description]
    */
   public function put ($aData = null, $aGetData = array()){
      return $this->_launch($this->_makeUrl( $aGetData),
                            $this->_createContext('PUT', $aData));
   }

   /**
    * [delete description]
    * @param  [type] $aData   [description]
    * @param  array  $aGetData [description]
    * @return [type]             [description]
    */
   public function delete ($aData = null, $aGetData = array()){
      return $this->_launch($this->_makeUrl( $aGetData),
                            $this->_createContext('DELETE', $aData));
   }
}
