<?php

use Image\Image\Image          as Image,
	Main\App\App               as App,
    Main\Route\Route           as Route,
    Core\Header\Header         as Header,
    Main\Controller\Controller as Controller,

    Image\Point\Point           as Point,
    Image\Box\Box               as Box;


$oImage        = new Image();
$sImageCurrent = Controller::getQuery('file').".".Route::get()->get('display');

$oBox          = new Box( Controller::getQuery('width'), Controller::getQuery('height'));
$oPoint        = new Point( Controller::getQuery('x'), Controller::getQuery('y'));

$sPathMedia    = App::get('pathDest')."croppe-".Controller::getQuery('x').Controller::getQuery('y').Controller::getQuery('width').Controller::getQuery('height')."_".$sImageCurrent;

if( !is_file( $sPathMedia)){

  $oImage->open( App::get('pathSrc').$sImageCurrent)
         ->crop( $oPoint, $oBox)
         ->save( $sPathMedia, App::get('option-save'));

}else{
    $sLastDate = date ("F d Y H:i:s.", filemtime( $sPathMedia));
    Header::setLastModified( $sLastDate);
}

App::set('path-media', $sPathMedia);
