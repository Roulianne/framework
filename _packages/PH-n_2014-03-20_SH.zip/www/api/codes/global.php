<?php

use Main\App\App             as App,
    Main\Conf\Conf           as Conf,
    Main\View\View           as View,
    Main\Route\Route         as Route;
