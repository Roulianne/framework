<?php

use Main\App\App               as App,
    Main\Route\Route           as Route,
    Main\Controller\Controller as Controller;

switch( Route::get()->get('display') ) {
    case "gif": $sType="image/gif"; break;
    case "png": $sType="image/png"; break;
    case "jpeg":
    case "jpg": $sType="image/jpg"; break;
    default:
}

$sPathFile = dirname(__FILE__).'/../../../_tmp/';

$sImageCurrent = Controller::getQuery('file').".".Route::get()->get('display');

header('Content-type:'.$sType);
readfile( $sPathFile.$sImageCurrent);
