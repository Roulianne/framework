<?php

use Image\Image\Image          as Image,
	  Main\App\App               as App,
    Main\Route\Route           as Route,
    Main\Controller\Controller as Controller,

    Image\Point\Point           as Point,
    Image\Box\Box               as Box;

App::get('option-save');

$oImage        = new Image();
$sImageCurrent = Controller::getQuery('file').".".Route::get()->get('display');

$oBox          = new Box( Controller::getQuery('width'), Controller::getQuery('height'));

$sMode  = Controller::getQuery('mode');
$iMarge = Controller::getQuery('marge');

$sMode  = ( strtolower( $sMode) == 'contain')? 'contain' : 'cover';

$sPathMedia     = App::get('pathDest').$sMode.'-'.$iMarge.Controller::getQuery('width').Controller::getQuery('height')."_".$sImageCurrent;

if( !is_file( $sPathMedia)){

  $oImage->open( App::get('pathSrc').$sImageCurrent)
         ->thumbnail(  $oBox, $sMode, $iMarge)
         ->effect()
         ->sharpen()
         ->stopEffect()
         ->save(  $sPathMedia, App::get('option-save'));

}

header('Content-type:'.App::get('content-type'));
readfile( $sPathMedia);
