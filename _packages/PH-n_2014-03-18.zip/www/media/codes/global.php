<?php

use Main\Route\Route    as Route,
    Main\App\App        as App;

switch( Route::get()->get('display') ) {
    case "gif": $sType="image/gif"; break;
    case "png": $sType="image/png"; break;
    case "jpeg":
    case "jpg": $sType="image/jpg"; break;
    default:
}

$sPathFile    = dirname(__FILE__).'/../../_tmp/';
$sPathFileTmp = $sPathFile.'thumb/';
$aOption      = array('quality' => 80);

App::set('content-type', $sType);
App::set('pathSrc',      $sPathFile);
App::set('pathDest',     $sPathFileTmp);
App::set('option-save',  $aOption );