<?php
namespace Core\Dao\Php;

use Core\Dao\Php\PhpDao as PhpDao,
    Core\Dao\Php\Accessible as Accessible,
    \Exception;

class JsonDao extends PhpDao implements Accessible
{

    public  $TYPE         = 'JSON';

    /**
     * [__construct description]
     * @param [type] $sFile
     */
    public function __construct($aParams)
    {
        if ( is_array( $aParams) and array_key_exists('file', $aParams)) {
            $aJson = json_decode( file_get_contents( $aParams['file']), true);
            if ( is_array( $aJson)) {
                $this->_aDataFile = $aJson;
            } else {
                throw new Exception("Format Json non valide");
            }
        } else {
            throw new Exception("Failed to open the file");
        }
    }

    /**
    * [read description]
    * @param  array  $aData [description]
    * @return [type]        [description]
    */
    public function read(  $aSelect = array())
    {
        return parent::read(  $aSelect);
    }

    /**
     * [create description]
     * @param  [type] $sTable
     * @param  array  $aData
     * @return [type]
     */
    public function create(array $aData)
    {
        //
    }

    /**
     * [update description]
     * @param  [type] $sTable
     * @param  array  $aData
     * @param  array  $aWhere
     * @return [type]
     */
    public function update(array $aData)
    {
        //
    }

    /**
     * [delete description]
     * @param  [type] $sTable
     * @param  array  $aWhere
     * @return [type]
     */
    public function delete()
    {
        //
    }

    /**
    * [getStructure description]
    * @param  object $oElment [description]
    * @return [type]          [description]
    */
    public function options( $oElement)
    {
        return $oElement->getStructure();
    }

    /**
    * [setCondition description]
    * @param [type] $aWhere [description]
    */
    public function setCondition(array $aWhere = array())
    {
        if (is_array( $aWhere)) {
            $this->_aWhere = $aWhere;
        }

        return $this;
    }

    /**
     * [setCustomCondition description]
     * @param string $sString [description]
     */
    public function setCustomCondition(array $aParams = array())
    {
        return $this;
    }
}
