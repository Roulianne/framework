<?php

namespace Main\Model;

use Core\Dao\Dao             as Dao,
    Core\Model\Model         as ModelCore,
    Main\Conf\Conf           as Conf,
    Main\Model\Stock\StockModel   as StockModel;

class Model extends ModelCore
{
    private  $_aOption  = array();

    /** @var array [description] */
    protected $_aSelect = array();
    protected $_aError  = array();

    private $_aFilter   = null;

    /**
     * [isValid description]
     * @param  [type]  $aData [description]
     * @return boolean [description]
     */
    protected function _isValid($aData)
    {
        $bValid = true;
        $aInput = $aData;

        $this->_aError = array();

        if ( count( $this->_getFilter())>0) {

            $aInput = filter_var_array( $aData, $this->_getFilter());

            foreach ($aInput as $sKey => $sValue) {
                if ( is_null( $sValue)) {
                    $this->_aError[$sKey] = 'required';
                    $bValid = false;
                }

                if ($sValue == false) {
                    $this->_aError[$sKey] = 'not conform';
                    $bValid = false;
                }
            }

            $aInput = array_merge($aData, $aInput);
        }

        return array( 'valid' => $bValid, 'data' => $aInput);

    }

    /**
     * [_getConf description]
     * @return [type] [description]
     */
    private function _getFilter()
    {
        if( is_null( $this->_aFilter)){

            $aStruture      = $this->getStructure();
            $this->_aFilter = array();

            foreach( $aStruture as $sChamp => $aInfo){
                if( array_key_exists('filter', $aInfo)){
                    $this->_aFilter[$sChamp] = $aInfo['filter'];
                }
            }
        }

        return $this->_aFilter;
    }

    /**
     * [_getConf description]
     * @return [type] [description]
     */
    protected function _getConf()
    {
        return Conf::get('model');
    }

    /**
     * [_buildDao description]
     * @return [type] [description]
     */
    protected function _buildDao()
    {
        $oDaoPdo = Dao::getInstance( $this->_getConf());

        return $oDaoPdo;
    }

    /**
     * [_returnObject description]
     * @param  [type] $aResult [description]
     * @return [type] [description]
     */
    protected function _returnObject($aResult)
    {
        $aResultObject = array();
        $sClassName    = get_class($this);

        foreach ($aResult as $aResultInfo) {

            $oElement = new $sClassName();
            $oElement->setOption( $this->_aOption)
                     ->setData( $aResultInfo);


            StockModel::addElement( $oElement, $this->getType());
            $aResultObject[] = $oElement;
        }


        return $aResultObject;
    }

     /**
     * [setOption description]
     */
    protected function _getOption( $sKey = ''){
        if( $sKey !== '' && array_key_exists( $sKey , $this->_aOption)){
            return $this->_aOption[$sKey];
        }

        return null;
    }

    /**
     * [getRefere description]
     * @return [type] [description]
     */
    public function getReferer(){
        return $this->_sPrefix.$this->_sRefererKey;
    }

    /**
     * [setSelect description]
     * @param [type] $aSelect [description]
     */
    public function setSelect( $aSelect = array())
    {
        $this->_aSelect = $aSelect;

        return $this;
    }

    /**
     * [getError description]
     * @return [type] [description]
     */
    public function getError()
    {
        return $this->_aError;
    }

    /**
     * [create description]
     * @param  array  $aValues [description]
     * @return [type] [description]
     */
    public function create( Array $aValues = array())
    {
        $aConditions =  array('type' =>$this->getType());

        if ( is_array( $aValid = $this->_isValid( $aValues)) AND $aValid['valid']) {

            $iLastId = $this->_oDao->setCondition( $aConditions)
                                   ->create( $aValid['data']);

            $aValues['id'] = $iLastId;
            $this->setData($aValues);
        }

        return $this;

    }

    /**
     * [_read description]
     * @param  [type] $mValue [description]
     * @param  string $sChamp [description]
     * @return [type] [description]
     */
    public function read($mValue, $sChamp = '')
    {

        if ($sChamp == '') {
            $aConditions =  array('type' =>$this->getType(),
                                  'where'=> array( $this->getReferer() => $mValue));

            if( StockModel::hasElement( $this->getType(), $mValue)){
                 return StockModel::getElement( $this->getType(), $mValue);
            }

        } else {

            $aConditions =  array('type' =>$this->getType(),
                                  'where'=> array( $sChamp => $mValue));
        }

        $aResult = $this->_oDao->setCondition( $aConditions)
                               ->read( $this->_aSelect);

        $this->setSelect();

        if ( !empty($aResult)) {
            $this->setData( $aResult[0]);
            StockModel::addElement( $this, $this->getType());
        }

        return true;
    }

    /**
     * [delete description]
     * @return [type] [description]
     */
    public function delete()
    {
        $aConditions =  array('type' =>$this->getType(),
                              'where'=> array( $this->getReferer() => $this->get($this->getReferer())),
                              'limit'=> array( '1'),
                              );

        $this->_oDao->setCondition( $aConditions)
                    ->delete();

        $this->setData( array());

        return $this;
    }

    /**
     * [save description]
     * @return [type] [description]
     */
    public function save()
    {
        $aConditions =  array('type' =>$this->getType(),
                              'where'=> array( $this->getReferer() => $this->get($this->getReferer())),
                              'limit'=> array( '1'),
                              );

       $aValues = $this->getData();

       if ( is_array( $aValid = $this->_isValid( $aValues)) AND $aValid['valid']) {

            $this->_oDao->setCondition( $aConditions)
                        ->update( $aValues );

            StockModel::setElement( $this, $this->getType());

        }

        return $this;
    }

    /**
     * [options description]
     * @param  object $oElement [description]
     * @return [type]           [description]
     */
    public function options() {

        $aConditions =  array('type' =>$this->getType(),
                              'where'=> array( $this->getReferer() => $this->get($this->getReferer())),
                              );

        return $this->_oDao->setCondition( $aConditions)
                           ->options( $this);
    }

    /**
     * [setOption description]
     */
    public function setOption( $aOption = array()){
        if( count( $aOption)>0 ){
            $this->_aOption = $aOption;
        }
        return $this;
    }

    /**
     * [reveal description]
     * @return [type] [description]
     */
    public function reveal( $aData = array())
    {
        if ( empty( $aData)) {
            $aResult = $this->getData();
        } else {
            $aResult = $aData;
        }

        if( !is_null( $aFields = $this->_getOption('fields'))){

            $aFields = array_map( function( $sParam){
                return $this->_cleanAttr( $sParam);
            } , $aFields);

            $aResult = array_intersect_key( $aResult, array_fill_keys( $aFields, ''));

        }

        return (object) $aResult;

    }

    /**
     * [reveal description]
     * @return [type] [description]
     */
    public function revealTiny( $aData = array())
    {
        if ( empty( $aData)) {
            $aResult  = array();
            $sReferer = $this->getReferer();
            $aResult[$sReferer] = $this->get( $sReferer);

        } else {
            $aResult = $aData;
        }

        if( !is_null( $aFields = $this->_getOption('fields'))){

            $aResult = array_intersect_key( $aResult, array_fill_keys( $aFields, ''));

        }

        return (object) $aResult;

    }

    /**
     * [all description]
     * @param  string $str [description]
     * @return [type] [description]
     */
    public function all($str = '')
    {
        if ($str != '') {
            $aParams = array('complement'=>$str);
            $aResult =  $this->_oDao->setCondition( array( 'type' => $this->getType()))
                                    ->setCustomCondition( $aParams)
                                    ->read();
        } else {
            $aResult =  $this->screen();
        }

        return $this->_returnObject( $aResult);
    }

    /**
     * [getStructure description]
     * @return [type] [description]
     */
    public function getStructure(){
        return array_keys( $this->reveal());
    }

    /**
     * [screen description]
     * @param  array  $aConditions [description]
     * @return [type] [description]
     */
    public function screen( $aConditions = array())
    {
        $aResultObject     = array();
        $aDefaultCondition = array('type'=>$this->getType());
        $aConditions       = array_merge( $aDefaultCondition, $aConditions);

        $aResult = $this->_oDao->setCondition( $aConditions)
                               ->read( $this->_aSelect);

        $this->setSelect();

        return $this->_returnObject( $aResult);
    }

}
