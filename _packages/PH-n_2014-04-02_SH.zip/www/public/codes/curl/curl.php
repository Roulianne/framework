<?php

use Main\View\View         as View,
	Main\App\App           as App,
	Main\Conf\Conf         as Conf,
	Main\Route\Route       as Route,
	Main\Uploader\Uploader as Uploader;

$sResponse = 'vide';

$aData = Route::post()->getData();

function clean( $sValue){
	return ltrim( $sValue, '@');
}

if( count( $aData)>0){
	$fCurl = curl_init();

	// Configuration de l'URL et d'autres options
	curl_setopt( $fCurl, CURLOPT_URL, $aData['url']);

	curl_setopt( $fCurl, CURLOPT_HEADER, true);
	curl_setopt( $fCurl, CURLOPT_VERBOSE , true);
	curl_setopt( $fCurl, CURLOPT_BINARYTRANSFER, true);
	curl_setopt( $fCurl, CURLOPT_RETURNTRANSFER, true);

	Uploader::upload();
	$aFile = Uploader::getFile();


	switch( $aData['method']){
		case 'post':
			$aData = array_map('clean', $aData);
			curl_setopt( $fCurl, CURLOPT_POST, true );

			if( count( $aFile)>0){
				$aFileTransfert = current( $aFile);
				$aData['curl'] = '@'.$aFileTransfert['destination'].$aFileTransfert['name'];
			}

			curl_setopt( $fCurl, CURLOPT_POSTFIELDS, $aData);
			break;

		case 'put':
			$aData = array_map('clean', $aData);

		    curl_setopt( $fCurl, CURLOPT_CUSTOMREQUEST, "PUT");
		    curl_setopt( $fCurl, CURLOPT_POSTFIELDS, http_build_query( $aData));

			break;

		case 'delete':
			curl_setopt( $fCurl, CURLOPT_CUSTOMREQUEST, "DELETE");
			break;

		default:
			break;
	}

	// Récupération de l'URL et affichage sur le naviguateur
	$sResponse = curl_exec( $fCurl);


	if( $sResponse === false){
		$sResponse = curl_error( $fCurl);
	}

	// Fermeture de la session cURL
	curl_close( $fCurl);
}

View::scope('*.textarea')->response  = htmlentities( $sResponse) ;
View::scope('*.textarea')->apiUrl    = ( isset( $aData['url']))? $aData['url'] : Conf::get('app.http_root').'api.json' ;

View::make( 'general.curl-test');
