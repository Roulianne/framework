<?php

use Main\App\App               as App,
    Main\Route\Route           as Route;

$aData =  Route::get()->getData();
/*
$aData['method'] = Route::getRequest()->getMethod();

switch( $aData['method']){
  case 'POST':
        $aData = Route::post()->getData();
    break;
  case 'PUT':
        $aData = Route::put()->getData();
    break;
  case 'DELETE':
  case 'GET':
    break;
}
*/

$oArticles = new Article();

$aData = array_map( function( $oModel){
	return $oModel->reveal();
}, $oArticles->all);

App::set('data', $aData);
