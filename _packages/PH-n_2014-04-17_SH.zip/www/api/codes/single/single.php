<?php

use Main\App\App               as App,
    Main\Route\Route           as Route;



$oArticle = new Article(2);

App::set('data', $oArticle->reveal());