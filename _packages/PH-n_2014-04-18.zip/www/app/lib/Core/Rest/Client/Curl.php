<?php

namespace Core\Rest\Client;

use Core\Rest\Client\Streaming       as Streaming;

class Curl extends Streaming
{
   protected static $_aRessourceCurl     = null;
   protected static $_rMultiCurl         = null;
   protected static $_bMultiCurl         = false;

   private $_sId = '';

   /**
    * [__construct description]
    */
   public function __construct(){
      $sId = strval(time());
      self::$_aRessourceCurl[$sId] = array( 'ressource' => curl_init(), 'state' => 0);
      $this->_sId = $sId;

      if( is_null( self::$_rMultiCurl) and count( self::$_aRessourceCurl)>1){
        self::$_rMultiCurl = curl_multi_init();
        self::$_bMultiCurl = true;
      }
   }

   /**
    * [_addToMultiRessourec description]
    */
   private function _addToMultiRessourec(){
     if( self::$_bMultiCurl){
        foreach ( self::$_aRessourceCurl as $sId => $aInfoRessourceCurl) {
          if( $aInfoRessourceCurl['state'] == 0){
            curl_multi_add_handle( self::$_rMultiCurl, $aInfoRessourceCurl['ressource']);
            self::$_aRessourceCurl[$sId]['state'] = 1;
          }
        }
     }
   }

   /**
    * [_getCurrentRessource description]
    * @return [type] [description]
    */
   protected function _getCurrentRessource(){
      return self::$_aRessourceCurl[$this->_sId]['ressource'];
   }

   /**
    * [_createContext description]
    * @param  [type] $pMethod  [description]
    * @param  [type] $aData [description]
    * @return [type]           [description]
    */
   protected function _createContext($pMethod, $aData = null){
     $aOption = array();

     switch( $pMethod){

        case'POST':
          $aOption = array(
                      CURLOPT_POST=>1,
                      CURLOPT_POSTFIELDS=>$aData,
                    );
          break;

        case'PUT':
          $aOption = array(
                      CURLOPT_CUSTOMREQUEST=>"PUT",
                      CURLOPT_POSTFIELDS=>http_build_query($aData),
                    );
          break;

        case'DELETE':
          $aOption = array(
                      CURLOPT_CUSTOMREQUEST=>"DELETE",
                    );
          break;

        case'GET':
        default:
          break;

     }

     return $aOption;
   }

   /**
    * [_launch description]
    * @param  [type] $pUrl    [description]
    * @param  [type] $context [description]
    * @return [type]          [description]
    */
   protected function _launch ($pUrl, $context){
        $rCurrent = $this->_getCurrentRessource();

        curl_setopt( $rCurrent, CURLOPT_URL, $pUrl);

        curl_setopt( $rCurrent, CURLOPT_HEADER, false);
        curl_setopt( $rCurrent, CURLOPT_VERBOSE , true);
        curl_setopt( $rCurrent, CURLOPT_BINARYTRANSFER, true);
        curl_setopt( $rCurrent, CURLOPT_RETURNTRANSFER, true);

        curl_setopt_array( $rCurrent, $context);

        $this->_addToMultiRessourec();

        $sResponse = curl_exec( $rCurrent);

        $aResponse = array(
              'content' => $sResponse,
              'header'  => '',
          );

        curl_close( $rCurrent);
        return $aResponse;
   }

}
