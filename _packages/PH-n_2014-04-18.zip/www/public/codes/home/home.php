<?php

use Main\App\App               as App,
    Main\Conf\Conf             as Conf,
    Main\View\View             as View,
    Main\Route\Route           as Route,
    Main\Event\Event           as Event,
    Main\Translator\Translator as Translator,
    Main\Controller\Controller as Controller;



$aInfo = array(
	'id'      =>'',
	'titre'   =>'julien',
	'date'    =>date('Y-m-d H:i:s'),
	'text'    =>'ajout par api',
	'preview' =>'image.jpg',
);

$oArticles = new Article( $aInfo);



$oArticles->setOption(array(
		'fields' => array('titre', 'time'),
));


View::scope('top.menu')->titre          = Controller::getQuery('code');
View::scope('top.menu')->option         = Controller::getQuery('theme');
View::scope('*')->content               = 'coucou';
View::scope('@top')->content            = 'TOP';
View::scope('*.citation')->content      = 'CITATION';


View::scope('*.citation')->pollux       = 'coucou ALL';
View::scope('header.citation')->pollux .= ' et du header';

View::scope('header.citation')->content = 'header';

View::scope('*.description')->articles    = $oArticles->all;

View::make( 'general.home');


if(  App::get('dev')){
	Event::trigger('plus');
}