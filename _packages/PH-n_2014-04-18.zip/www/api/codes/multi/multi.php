<?php

use Main\App\App               as App,
    Main\Route\Route           as Route;

$aData =  Route::get()->getData();

$sMethod = Route::getRequest()->getMethod();

switch( $sMethod){
  case 'POST':
        $aData     = Route::post()->getData();
        $oArticles = new Article( $aData);
        $aData     = array('statue'=>'success', 'message'=>'Article ajouter correctement');
    break;
  case 'GET':
    $oArticles = new Article();

    $aData = array_map( function( $oModel){
    	return $oModel->reveal();
    }, $oArticles->all);

    break;
  default:
    $aData = array('statue'=>'error', 'message'=>'Methode non reconnue pour ce format d\'url');
    break;
}



App::set('data', $aData);
