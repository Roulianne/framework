<?php

use Main\App\App               as App,
    Main\Route\Route           as Route,
    Main\Controller\Controller as Controller;


$sImageCurrent = Controller::getQuery('file').".".Route::get()->get('display');

App::set('path-media', App::get('pathSrc').$sImageCurrent);