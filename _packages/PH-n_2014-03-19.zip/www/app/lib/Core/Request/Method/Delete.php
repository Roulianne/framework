<?php

namespace Core\Request\Method;

use Core\Request\Method\Method as Method;

class Delete extends Method
{
    /**
     * [$_sType description]
     * @var string
     */
    protected $_sType = 'delete';

}
